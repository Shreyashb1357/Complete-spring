package welcome;
import org.springframework.stereotype.Component;
@Component
public class WelcomeComponent {
	public void doWork() {
		System.out.println("Welcome component works...");
	}
}
