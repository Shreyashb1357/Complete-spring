package example.spring.core.annotation;

public class HelloService {
	public void sayHello() {
		System.out.println("Hello Everyone !!");
	}
}
