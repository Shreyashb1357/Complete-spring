package example.spring.core.annotation;

public class CourseService {
	public CourseService() {
		
	}
	public CourseService(String behaviour) {
		System.out.println("Inside CourseService(String) with behaviour: " + behaviour );
	}
	//Some Code Further

	
}
