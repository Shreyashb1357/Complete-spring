package example.spring.core.annotation;

public class WelcomeService {
	public void sayWelcome() {
		System.out.println("Welcome Everyone !!");
	}
}
