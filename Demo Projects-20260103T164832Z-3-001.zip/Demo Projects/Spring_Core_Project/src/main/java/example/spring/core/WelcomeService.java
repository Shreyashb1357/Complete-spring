package example.spring.core;

public class WelcomeService implements GreetingService{

	@Override
	public String sayGreeting() {
		// TODO Auto-generated method stub
		return "Welcome to Spring";
	}

}
